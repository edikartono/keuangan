-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Waktu pembuatan: 03 Jan 2026 pada 06.43
-- Versi server: 11.8.3-MariaDB-log
-- Versi PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u696035254_keuangan_af`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `tipe` enum('Pemasukan','Pengeluaran') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id`, `nama_kategori`, `tipe`) VALUES
(1, 'Gaji', 'Pemasukan'),
(2, 'Bonus', 'Pemasukan'),
(3, 'Penjualan Produk', 'Pemasukan'),
(4, 'Lain-lain (Pemasukan)', 'Pemasukan'),
(5, 'Makanan & Minuman', 'Pengeluaran'),
(6, 'Transportasi', 'Pengeluaran'),
(7, 'Tagihan & Utilitas', 'Pengeluaran'),
(8, 'Belanja', 'Pengeluaran'),
(9, 'Hiburan', 'Pengeluaran'),
(10, 'Lain-lain (Pengeluaran)', 'Pengeluaran'),
(15, '5', 'Pemasukan'),
(18, 'test', 'Pemasukan'),
(19, 'pengeluaran', 'Pemasukan'),
(20, 'test pengeluaran', 'Pemasukan'),
(21, 'test20', 'Pengeluaran');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mutasi`
--

CREATE TABLE `mutasi` (
  `id` int(11) NOT NULL,
  `sumber_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `debit` decimal(16,2) DEFAULT 0.00,
  `kredit` decimal(16,2) DEFAULT 0.00,
  `saldo` decimal(16,2) DEFAULT 0.00,
  `transaksi_id` int(11) DEFAULT NULL,
  `jenis_transaksi` enum('pendapatan','pengeluaran') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `mutasi`
--

INSERT INTO `mutasi` (`id`, `sumber_id`, `tanggal`, `keterangan`, `debit`, `kredit`, `saldo`, `transaksi_id`, `jenis_transaksi`, `created_at`) VALUES
(1, 1, '2025-01-01', 'Saldo Awal Infak Harian', 1000000.00, 0.00, 1000000.00, NULL, 'pendapatan', '2025-11-24 07:42:43'),
(2, 1, '2025-01-05', 'Pembelian air mineral', 0.00, 50000.00, 950000.00, NULL, 'pengeluaran', '2025-11-24 07:42:43'),
(3, 2, '2025-01-03', 'Donatur Tetap Bulanan', 500000.00, 0.00, 500000.00, NULL, 'pendapatan', '2025-11-24 07:42:43'),
(4, 3, '2025-01-10', 'Kotak Jumat', 300000.00, 0.00, 300000.00, NULL, 'pendapatan', '2025-11-24 07:42:43');

-- --------------------------------------------------------

--
-- Struktur dari tabel `saldo_awal`
--

CREATE TABLE `saldo_awal` (
  `id` int(11) NOT NULL,
  `sumber_id` int(11) NOT NULL,
  `saldo_awal` decimal(16,2) NOT NULL,
  `tahun` int(11) NOT NULL,
  `bulan` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `sumber_dana`
--

CREATE TABLE `sumber_dana` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `saldo_awal` double DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sumber_dana`
--

INSERT INTO `sumber_dana` (`id`, `nama`, `saldo_awal`, `created_at`) VALUES
(1, 'Infak Harian', 0, '2025-11-24 04:32:27'),
(2, 'Donatur Tetap', 0, '2025-11-24 04:32:27'),
(3, 'Sedekah Jumat', 0, '2025-11-24 04:32:27'),
(4, 'Operasional RT', 0, '2025-11-24 04:32:27');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `sumber_dana_id` int(11) DEFAULT NULL,
  `tipe` enum('Pemasukan','Pengeluaran') NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `keterangan` text NOT NULL,
  `tanggal` date NOT NULL,
  `dibuat_pada` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id`, `user_id`, `kategori_id`, `sumber_dana_id`, `tipe`, `jumlah`, `keterangan`, `tanggal`, `dibuat_pada`) VALUES
(1, 1, 3, 4, 'Pemasukan', 1000000.00, 'web sekolah', '2025-06-24', '2025-06-24 15:48:19'),
(3, 1, 9, 2, 'Pengeluaran', 250000.00, 'jalan jalan ke dumai', '2025-06-24', '2025-06-24 15:51:58'),
(4, 1, 2, 2, 'Pemasukan', 2200000.00, 'mapskey bosku', '2025-06-24', '2025-06-24 16:09:30'),
(5, 1, 8, 2, 'Pengeluaran', 95000.00, 'makan bakso', '2025-06-24', '2025-06-24 16:14:35'),
(6, 1, 2, 1, 'Pemasukan', 1000000.00, 'Test1', '2025-12-08', '2025-12-08 15:42:45'),
(15, 1, 15, 0, 'Pemasukan', 1.00, '1', '2026-01-02', '2026-01-02 03:47:01'),
(22, 1, 15, 0, 'Pemasukan', 1.00, '1', '2026-01-02', '2026-01-02 03:54:49'),
(23, 1, 15, 0, 'Pemasukan', 1.00, '1', '2026-01-02', '2026-01-02 03:55:04'),
(24, 1, 15, 0, 'Pemasukan', 1.00, '1', '2026-01-02', '2026-01-02 03:55:28'),
(25, 1, 15, 0, 'Pemasukan', 1.00, '1', '2026-01-02', '2026-01-02 07:53:09'),
(26, 1, 2, NULL, 'Pemasukan', 100.00, '1', '2026-01-02', '2026-01-02 07:58:42'),
(27, 1, 15, NULL, 'Pemasukan', 500.00, '5', '2026-01-02', '2026-01-02 07:59:17'),
(28, 1, 2, 2, 'Pemasukan', 5000000.00, '555', '2026-01-01', '2026-01-02 08:04:43');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dibuat_pada` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nama_lengkap`, `username`, `password`, `dibuat_pada`) VALUES
(1, 'ihsan', 'admin', '$2y$10$gDBGg0kFuvzq5zutDPkPI.iommKaWKkJxAHRQfRIXYXQleOrtTSle', '2025-06-24 15:17:12');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `mutasi`
--
ALTER TABLE `mutasi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_mutasi_sumber_tanggal` (`sumber_id`,`tanggal`);

--
-- Indeks untuk tabel `saldo_awal`
--
ALTER TABLE `saldo_awal`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `sumber_dana`
--
ALTER TABLE `sumber_dana`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `kategori_id` (`kategori_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT untuk tabel `mutasi`
--
ALTER TABLE `mutasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `saldo_awal`
--
ALTER TABLE `saldo_awal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `sumber_dana`
--
ALTER TABLE `sumber_dana`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
